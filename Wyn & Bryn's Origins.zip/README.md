Welcome to Wyn & Bryn's Origins!

We wanted to use Origins on a Paper server. This has many issues, namely the fact that Paper kind of sucks.
So we wrote this from scratch.

Current origins available:

-- Blaze
-- Cat
-- Cow
-- Dwarf
-- Dragon
-- Skeleton
-- Zombie
-- Player
-- Fae Blooded
-- Robot
-- Dryad
-- Warden Blooded
-- Sculk Angel